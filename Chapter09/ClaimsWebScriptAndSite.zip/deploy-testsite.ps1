﻿<#
  This script and accompanying code are provided for education purposes only, for use with http://blogs.technet.com/b/askpfeplat/archive/2013/12/23/how-to-build-your-adfs-lab-on-server-2012-part2-web-sso.aspx

  Aaand, the legal stuff:

  Disclaimer: The sample scripts are not supported under any Microsoft standard support program or service. 
  The sample scripts are provided AS IS without warranty of any kind. Microsoft further disclaims all implied 
  warranties including, without limitation, any implied warranties of merchantability or of fitness for a 
  particular purpose. The entire risk arising out of the use or performance of the sample scripts and documentation 
  remains with you. In no event shall Microsoft, its authors, or anyone else involved in the creation, production, 
  or delivery of the scripts be liable for any damages whatsoever (including, without limitation, damages for loss of 
  business profits, business interruption, loss of business information, or other pecuniary loss) arising out of the 
  use of or inability to use the sample scripts or documentation, even if Microsoft has been advised of the possibility
   of such damages.

#>

param([string]$SourcePath,
      [string]$SiteName,     
      [string]$SitePhysicalPath,
      [string]$ADFSServer,
      [string]$AppFQDN,
      [string]$MediaPath)


#install features


Install-WindowsFeature Net-Framework-Core,NET-FrameWork-45-Core,Net-Framework-45-ASPNET #-Source $MediaPath
Install-WindowsFeature Windows-Identity-Foundation
Install-WindowsFeature Web-Server,Web-Common-Http,Web-Default-Doc,Web-Dir-Browsing,Web-Http-Errors,Web-Static-Content,Web-Custom-Logging,Web-Stat-Compression,Web-Filtering,Web-Windows-Auth,Web-Net-Ext,Web-Net-Ext45,Web-Asp-Net,Web-Asp-Net45 -IncludeManagementTools


#get ADFS info - Federation Service Identifier, Thumbprint, Endpoint
$session = New-PSSession -ComputerName $ADFSServer
$Thumbprint = Invoke-Command -Session $session -ScriptBlock { (Get-ADFSCertificate -CertificateType:Token-Signing).Thumbprint }

switch -Wildcard ((Get-WmiObject Win32_OperatingSystem -ComputerName $ADFSServer).version)
{
    6.2* { $ServiceID = Invoke-Command -Session $session -ScriptBlock { (Get-ADFSConfiguration).Identifier.Originalstring } }
    6.3* { $ServiceID = Invoke-Command -Session $session -ScriptBlock { (Get-ADFSProperties).Identifier.Originalstring } }
} 

$ADFSSAML2Endpoint = (Invoke-Command -Session $session -ScriptBlock { Get-ADFSEndpoint | where { $_.Protocol -eq "SAML 2.0/WS-Federation" }  }).FullUrl.AbsoluteUri
$ADFSMetadataEndpoint = (Invoke-Command -Session $session -ScriptBlock { Get-ADFSEndpoint | where { $_.Protocol -eq "Federation Metadata" }  }).FullUrl.AbsoluteUri


#create self signed cert
$cert = New-SelfSignedCertificate -DnsName $AppFQDN -CertStoreLocation CERT:\localMachine\My

#create physical path
if((test-path $SitePhysicalPath) -eq $false)
{
    New-Item $SitePhysicalPath -ItemType Directory
}

#Create app pool and site, add SSL binding and cert
$AppPool = New-WebAppPool -Name $SiteName 
set-WebConfigurationproperty "/system.applicationHost/applicationPools/add[@name=`"$sitename`"]" -name "ProcessModel" -value (@{loadUserProfile="true"})

$Site = New-Website -Name $SiteName -Port 80 -IPAddress "*" -PhysicalPath $SitePhysicalPath -ApplicationPool $SiteName -HostHeader $AppFQDN
New-WebBinding -Name $SiteName -IPAddress "*" -Port 443 -SslFlags 0 -Protocol HTTPS -HostHeader $AppFQDN
(Get-WebBinding -Protocol HTTPS -Port 443 -HostHeader $appFQDN).AddSslCertificate($cert.GetCertHashString(), "MY")

#copy code from Sourcepath
copy-item -Recurse "$SourcePath\*" $SitePhysicalPath

#modify web.config
$webConfigTemplate = join-path $SitePhysicalPath "Web.config.template"
$webConfigContent = get-content $webConfigTemplate
$webconfigContent = $webConfigContent.Replace("SAML2URI", $ADFSSAML2Endpoint)
$webconfigContent = $webConfigContent.Replace("APPLICATIONFQDN", $AppFQDN)
$webconfigContent = $webConfigContent.Replace("STSTHUMBPRINT", $Thumbprint)
$webconfigContent = $webconfigContent.Replace("SERVICEIDURI", $ServiceID)
$webConfigContent = $webconfigContent.Replace("FEDERATIONMETADATAURI", $ADFSMetadataEndpoint)
set-content (join-path $SitePhysicalPath web.config) $webConfigContent

#Modify metadata document
$fedMetaDataTemplate = join-path $SitePhysicalPath "FederationMetaData\2007-06\FederationMetadata.xml.template"
$MetadataDoc = get-content $fedMetaDataTemplate
$MetadataDoc = $MetadataDoc.Replace("APPLICATIONFQDN", $AppFQDN)
Set-Content (Join-Path $SitePhysicalPath "FederationMetaData\2007-06\FederationMetadata.xml") $MetadataDoc



